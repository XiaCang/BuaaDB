# BuaaDB

server/app.py 为后端服务入口
通过 python server/app.py 启动服务

前端启动命令:
npm install 
npm run dev
随后访问 http://localhost:5173 即可


或者直接可以打开dist目录下的index.html直接启动